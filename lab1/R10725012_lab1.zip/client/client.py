import requests

requests.get('http://backend:5000')

# add success log by my self
print('client connect to server successfully. exit.')
