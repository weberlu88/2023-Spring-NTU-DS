import requests

requests.get('http://backend:5001')

# add success log by my self
print('client connect to server successfully. exit.')
